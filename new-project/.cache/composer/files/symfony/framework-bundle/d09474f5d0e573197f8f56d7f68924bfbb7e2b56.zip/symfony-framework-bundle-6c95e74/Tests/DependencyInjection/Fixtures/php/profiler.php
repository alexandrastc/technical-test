<?php

$container->loadFromExtension('framework', [
    'profiler' => [
        'enabled' => true,
    ],
]);

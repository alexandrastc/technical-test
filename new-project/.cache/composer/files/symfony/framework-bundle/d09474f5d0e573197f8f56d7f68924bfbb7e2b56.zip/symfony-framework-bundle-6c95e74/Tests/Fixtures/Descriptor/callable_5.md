
- Type: `function`
- Name: `staticMethod`
- Class: `Symfony\Bundle\FrameworkBundle\Tests\Console\Descriptor\ExtendedCallableClass`
- Static: yes
- Parent: yes

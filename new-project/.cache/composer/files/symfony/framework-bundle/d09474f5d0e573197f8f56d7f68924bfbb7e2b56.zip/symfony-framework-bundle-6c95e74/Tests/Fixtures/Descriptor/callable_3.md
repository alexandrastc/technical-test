
- Type: `function`
- Name: `method`
- Class: `Symfony\Bundle\FrameworkBundle\Tests\Console\Descriptor\CallableClass`

<?php

$container->loadFromExtension('framework', [
    'translator' => false,
    'templating' => [
        'engines' => ['php'],
    ],
]);

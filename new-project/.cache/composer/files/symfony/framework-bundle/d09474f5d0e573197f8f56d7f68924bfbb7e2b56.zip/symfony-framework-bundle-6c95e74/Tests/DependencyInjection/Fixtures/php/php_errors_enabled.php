<?php

$container->loadFromExtension('framework', [
    'php_errors' => [
        'log' => true,
        'throw' => true,
    ],
]);

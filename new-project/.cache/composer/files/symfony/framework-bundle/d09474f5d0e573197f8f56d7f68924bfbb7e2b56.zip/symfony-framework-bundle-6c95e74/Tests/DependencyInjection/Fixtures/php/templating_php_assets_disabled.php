<?php

$container->loadFromExtension('framework', [
    'assets' => false,
    'templating' => [
        'engines' => ['php'],
    ],
]);

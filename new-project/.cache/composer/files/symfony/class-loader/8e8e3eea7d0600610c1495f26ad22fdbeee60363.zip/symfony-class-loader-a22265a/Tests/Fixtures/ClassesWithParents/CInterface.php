<?php

namespace ClassesWithParents;

interface CInterface extends GInterface
{
}

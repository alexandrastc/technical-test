<?php

/*
 * foo
 */

namespace Namespaced;

class WithHaltCompiler
{
}

// the end of the script execution
__halt_compiler(); data
data
data
data
...

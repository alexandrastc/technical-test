<?php

namespace Symfony\Component\Config\Tests\Fixtures;

class ParseError
{
// missing closing bracket
